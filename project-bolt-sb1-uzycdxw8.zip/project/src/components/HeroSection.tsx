import React from 'react';

const HeroSection: React.FC = () => {
  return (
    <section className="relative bg-[#2d2d2d] py-16 md:py-24">
      <div className="container mx-auto px-6 md:px-12">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-8 md:mb-0">
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4">
              Rent Your Perfect Car Today
            </h2>
            <p className="text-lg text-gray-300 mb-6">
              Experience the freedom of the open road with our premium fleet of vehicles.
              From economy to luxury, we have the perfect car for your next adventure.
            </p>
            <button className="bg-[#ffd700] hover:bg-[#ffed4a] text-black font-medium py-3 px-6 rounded-md transition-colors duration-300 shadow-md">
              Explore Our Fleet
            </button>
          </div>
          <div className="md:w-1/2">
            <img 
              src="https://images.pexels.com/photos/170811/pexels-photo-170811.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
              alt="Luxury car" 
              className="w-full h-auto rounded-lg shadow-lg"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;