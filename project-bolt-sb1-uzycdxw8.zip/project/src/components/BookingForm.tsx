import React, { useState } from 'react';

const BookingForm: React.FC = () => {
  const [formData, setFormData] = useState({
    pickupLocation: '',
    pickupDateTime: '',
    returnDateTime: '',
    vehicleType: '',
    customerName: '',
    email: '',
    phone: ''
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
    
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: ''
      });
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.pickupLocation.trim()) {
      newErrors.pickupLocation = 'Pickup location is required';
    }
    
    if (!formData.pickupDateTime) {
      newErrors.pickupDateTime = 'Pickup date and time is required';
    }
    
    if (!formData.returnDateTime) {
      newErrors.returnDateTime = 'Return date and time is required';
    } else if (formData.pickupDateTime && new Date(formData.returnDateTime) <= new Date(formData.pickupDateTime)) {
      newErrors.returnDateTime = 'Return date must be after pickup date';
    }
    
    if (!formData.vehicleType) {
      newErrors.vehicleType = 'Vehicle type is required';
    }
    
    if (!formData.customerName.trim()) {
      newErrors.customerName = 'Name is required';
    }
    
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Email is invalid';
    }
    
    if (!formData.phone.trim()) {
      newErrors.phone = 'Phone number is required';
    } else if (!/^\d{10,15}$/.test(formData.phone.replace(/[-()\s]/g, ''))) {
      newErrors.phone = 'Phone number is invalid';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (validateForm()) {
      alert('Booking submitted successfully!');
      console.log(formData);
      
      setFormData({
        pickupLocation: '',
        pickupDateTime: '',
        returnDateTime: '',
        vehicleType: '',
        customerName: '',
        email: '',
        phone: ''
      });
    }
  };

  return (
    <section className="py-12 px-6 md:px-12 bg-[#1a1a1a]">
      <div className="container mx-auto">
        <h2 className="text-2xl md:text-3xl font-bold text-center text-white mb-8">Book Your Rental</h2>
        
        <div className="max-w-3xl mx-auto bg-[#2d2d2d] rounded-lg shadow-xl p-6 md:p-8 border border-gray-700">
          <form onSubmit={handleSubmit}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="col-span-1">
                <label htmlFor="pickupLocation" className="block text-sm font-medium text-gray-300 mb-1">
                  Pick-up Location
                </label>
                <input
                  type="text"
                  id="pickupLocation"
                  name="pickupLocation"
                  value={formData.pickupLocation}
                  onChange={handleChange}
                  className={`w-full px-4 py-2 bg-[#1a1a1a] border rounded-md focus:outline-none focus:ring-2 focus:ring-[#ffd700] text-white ${
                    errors.pickupLocation ? 'border-red-500' : 'border-gray-600'
                  }`}
                  placeholder="Enter city or airport"
                />
                {errors.pickupLocation && (
                  <p className="mt-1 text-sm text-red-500">{errors.pickupLocation}</p>
                )}
              </div>
              
              <div className="col-span-1">
                <label htmlFor="vehicleType" className="block text-sm font-medium text-gray-300 mb-1">
                  Vehicle Type
                </label>
                <select
                  id="vehicleType"
                  name="vehicleType"
                  value={formData.vehicleType}
                  onChange={handleChange}
                  className={`w-full px-4 py-2 bg-[#1a1a1a] border rounded-md focus:outline-none focus:ring-2 focus:ring-[#ffd700] text-white ${
                    errors.vehicleType ? 'border-red-500' : 'border-gray-600'
                  }`}
                >
                  <option value="">Select vehicle type</option>
                  <option value="Economy">Economy</option>
                  <option value="Mid-size">Mid-size</option>
                  <option value="SUV">SUV</option>
                  <option value="Luxury">Luxury</option>
                </select>
                {errors.vehicleType && (
                  <p className="mt-1 text-sm text-red-500">{errors.vehicleType}</p>
                )}
              </div>
              
              <div className="col-span-1">
                <label htmlFor="pickupDateTime" className="block text-sm font-medium text-gray-300 mb-1">
                  Pick-up Date & Time
                </label>
                <input
                  type="datetime-local"
                  id="pickupDateTime"
                  name="pickupDateTime"
                  value={formData.pickupDateTime}
                  onChange={handleChange}
                  className={`w-full px-4 py-2 bg-[#1a1a1a] border rounded-md focus:outline-none focus:ring-2 focus:ring-[#ffd700] text-white ${
                    errors.pickupDateTime ? 'border-red-500' : 'border-gray-600'
                  }`}
                />
                {errors.pickupDateTime && (
                  <p className="mt-1 text-sm text-red-500">{errors.pickupDateTime}</p>
                )}
              </div>
              
              <div className="col-span-1">
                <label htmlFor="returnDateTime" className="block text-sm font-medium text-gray-300 mb-1">
                  Return Date & Time
                </label>
                <input
                  type="datetime-local"
                  id="returnDateTime"
                  name="returnDateTime"
                  value={formData.returnDateTime}
                  onChange={handleChange}
                  className={`w-full px-4 py-2 bg-[#1a1a1a] border rounded-md focus:outline-none focus:ring-2 focus:ring-[#ffd700] text-white ${
                    errors.returnDateTime ? 'border-red-500' : 'border-gray-600'
                  }`}
                />
                {errors.returnDateTime && (
                  <p className="mt-1 text-sm text-red-500">{errors.returnDateTime}</p>
                )}
              </div>
              
              <div className="col-span-1">
                <label htmlFor="customerName" className="block text-sm font-medium text-gray-300 mb-1">
                  Customer Name
                </label>
                <input
                  type="text"
                  id="customerName"
                  name="customerName"
                  value={formData.customerName}
                  onChange={handleChange}
                  className={`w-full px-4 py-2 bg-[#1a1a1a] border rounded-md focus:outline-none focus:ring-2 focus:ring-[#ffd700] text-white ${
                    errors.customerName ? 'border-red-500' : 'border-gray-600'
                  }`}
                  placeholder="Full name"
                />
                {errors.customerName && (
                  <p className="mt-1 text-sm text-red-500">{errors.customerName}</p>
                )}
              </div>
              
              <div className="col-span-1">
                <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-1">
                  Email Address
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  className={`w-full px-4 py-2 bg-[#1a1a1a] border rounded-md focus:outline-none focus:ring-2 focus:ring-[#ffd700] text-white ${
                    errors.email ? 'border-red-500' : 'border-gray-600'
                  }`}
                  placeholder="email@example.com"
                />
                {errors.email && (
                  <p className="mt-1 text-sm text-red-500">{errors.email}</p>
                )}
              </div>
              
              <div className="col-span-1 md:col-span-2">
                <label htmlFor="phone" className="block text-sm font-medium text-gray-300 mb-1">
                  Phone Number
                </label>
                <input
                  type="tel"
                  id="phone"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  className={`w-full px-4 py-2 bg-[#1a1a1a] border rounded-md focus:outline-none focus:ring-2 focus:ring-[#ffd700] text-white ${
                    errors.phone ? 'border-red-500' : 'border-gray-600'
                  }`}
                  placeholder="(123) 456-7890"
                />
                {errors.phone && (
                  <p className="mt-1 text-sm text-red-500">{errors.phone}</p>
                )}
              </div>
            </div>
            
            <div className="mt-8 flex justify-center">
              <button
                type="submit"
                className="bg-[#ffd700] hover:bg-[#ffed4a] text-black font-medium py-3 px-8 rounded-md transition-colors duration-300 shadow-md w-full md:w-auto"
              >
                Book Now
              </button>
            </div>
          </form>
        </div>
      </div>
    </section>
  );
};

export default BookingForm;