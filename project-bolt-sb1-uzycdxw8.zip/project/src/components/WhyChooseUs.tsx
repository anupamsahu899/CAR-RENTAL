import React from 'react';
import { ShieldCheck, Clock, Wallet } from 'lucide-react';

const WhyChooseUs: React.FC = () => {
  const benefits = [
    {
      icon: <ShieldCheck className="h-10 w-10 text-[#ffd700]" />,
      title: 'Quality Assured',
      description: 'All our vehicles undergo rigorous maintenance checks to ensure your safety and comfort.'
    },
    {
      icon: <Clock className="h-10 w-10 text-[#ffd700]" />,
      title: 'Fast & Easy Booking',
      description: 'Our streamlined booking process takes less than 2 minutes, saving you time and hassle.'
    },
    {
      icon: <Wallet className="h-10 w-10 text-[#ffd700]" />,
      title: 'Best Price Guarantee',
      description: 'We offer competitive rates with no hidden fees and price-match against major competitors.'
    }
  ];

  return (
    <section className="py-12 md:py-16 bg-[#1a1a1a] px-6 md:px-12">
      <div className="container mx-auto">
        <h2 className="text-2xl md:text-3xl font-bold text-center text-white mb-12">Why Choose Us</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {benefits.map((benefit, index) => (
            <div 
              key={index} 
              className="bg-[#2d2d2d] p-6 rounded-lg shadow-xl border border-gray-700 text-center transition-transform duration-300 hover:transform hover:scale-105"
            >
              <div className="flex justify-center mb-4">{benefit.icon}</div>
              <h3 className="text-xl font-semibold text-white mb-3">{benefit.title}</h3>
              <p className="text-gray-300">{benefit.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WhyChooseUs;