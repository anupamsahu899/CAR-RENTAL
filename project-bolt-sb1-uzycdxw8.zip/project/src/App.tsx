import React from 'react';
import Header from './components/Header';
import HeroSection from './components/HeroSection';
import BookingForm from './components/BookingForm';
import WhyChooseUs from './components/WhyChooseUs';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen flex flex-col bg-[#1a1a1a]">
      <Header />
      <main className="flex-grow pt-16">
        <HeroSection />
        <BookingForm />
        <WhyChooseUs />
      </main>
      <Footer />
    </div>
  );
}

export default App;